from enum import Enum


class Tag(Enum):
    HAND_LANDMARKS = 0
    HAND_GESTURE = 1
